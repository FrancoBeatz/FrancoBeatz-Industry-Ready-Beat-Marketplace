
import { getSupabaseAdmin } from '../supabase';

export default async function handler(req: any, res: any) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { email } = req.body;
  const supabaseAdmin = getSupabaseAdmin();

  try {
    const { error } = await supabaseAdmin.auth.resetPasswordForEmail(email);
    if (error) throw error;
    return res.status(200).json({ success: true, message: "Recovery email sent" });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || "Recovery failed" });
  }
}
