
import { createClient } from '@supabase/supabase-js';

// Configuration
const config = {
  supabaseUrl: process.env.SUPABASE_URL || 'https://bgrvsidbjvwtiroirssk.supabase.co',
  supabaseServiceKey: process.env.SUPABASE_SERVICE_ROLE_KEY || 'sb_secret_w6MQT_kAVhg6kIVD_fWaXg_1g5oXlon',
  port: process.env.PORT || 3000
};

// Initialize Supabase Admin (Server Side Only)
const supabaseAdmin = createClient(config.supabaseUrl, config.supabaseServiceKey);

/**
 * PRODUCTION ERROR HANDLER
 */
const handleError = (res: any, error: any, message = 'Internal Server Error') => {
  console.error(`[API ERROR]: ${error.message || error}`);
  return res.status(error.status || 500).json({
    success: false,
    error: error.message || message
  });
};

/**
 * AUTH CONTROLLERS
 */
export const authControllers = {
  register: async (req: any, res: any) => {
    const { email, password, name } = req.body;
    try {
      if (!email || !password) throw { status: 400, message: "Email and password required" };

      const { data: authUser, error: authError } = await supabaseAdmin.auth.admin.createUser({
        email,
        password,
        email_confirm: true,
        user_metadata: { full_name: name }
      });
      if (authError) throw authError;

      const { error: profileError } = await supabaseAdmin
        .from('profiles')
        .insert([{ id: authUser.user.id, email, role: 'CUSTOMER' }]);
      if (profileError) throw profileError;

      return res.status(201).json({ success: true, message: "User registered successfully", userId: authUser.user.id });
    } catch (err: any) {
      return handleError(res, err, "Registration failed");
    }
  },

  forgotPassword: async (req: any, res: any) => {
    const { email } = req.body;
    try {
      const { error } = await supabaseAdmin.auth.resetPasswordForEmail(email, {
        redirectTo: `${req.headers.origin}/reset-password`,
      });
      if (error) throw error;
      return res.json({ success: true, message: "Recovery email sent" });
    } catch (err: any) {
      return handleError(res, err, "Recovery failed");
    }
  }
};

/**
 * STRIPE & PAYMENTS
 */
export const stripeControllers = {
  createSession: async (req: any, res: any) => {
    try {
      const { items } = req.body;
      if (!items || items.length === 0) throw { status: 400, message: "Cart is empty" };

      // In production: const session = await stripe.checkout.sessions.create({...});
      const simulatedSessionId = `cs_live_${Math.random().toString(36).substr(2, 9)}`;
      
      return res.json({ success: true, sessionId: simulatedSessionId });
    } catch (err: any) {
      return handleError(res, err, "Stripe session creation failed");
    }
  }
};

/**
 * BEAT MANAGEMENT (ADMIN PROTECTED)
 */
export const adminControllers = {
  updateBeat: async (req: any, res: any) => {
    const { id } = req.params;
    const updates = req.body;
    try {
      const { data, error } = await supabaseAdmin
        .from('beats')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return res.json({ success: true, data });
    } catch (err: any) {
      return handleError(res, err, "Update failed");
    }
  }
};
