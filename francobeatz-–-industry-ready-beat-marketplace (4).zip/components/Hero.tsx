
import React from 'react';

const Hero: React.FC<{ onOpenAuth: () => void; onOpenRegister: () => void }> = ({ onOpenAuth, onOpenRegister }) => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      <div className="absolute top-1/4 -left-20 w-96 h-96 bg-purple-600/20 rounded-full blur-[120px]"></div>
      <div className="absolute bottom-1/4 -right-20 w-96 h-96 bg-blue-600/10 rounded-full blur-[120px]"></div>
      
      <div className="container mx-auto px-6 relative z-10 text-center">
        <div className="inline-block px-4 py-1.5 mb-6 bg-white/5 border border-white/10 rounded-full">
          <span className="text-xs font-bold tracking-[0.2em] text-purple-400 uppercase">Premium Sound Design</span>
        </div>
        
        <h1 className="text-5xl md:text-8xl font-black mb-8 font-poppins leading-tight tracking-tight uppercase italic">
          INDUSTRY-READY <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-600">TRAP & HIP-HOP</span>
        </h1>
        
        <p className="max-w-2xl mx-auto text-gray-400 text-lg md:text-xl mb-12 leading-relaxed font-light">
          Unlock your true potential with beats engineered for the charts. Used by top independent artists worldwide. High-quality stems, instant delivery, and fair licensing.
        </p>
        
        <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
          <a href="#beats" className="w-full sm:w-auto px-10 py-5 bg-purple-600 hover:bg-purple-700 text-white font-black rounded-xl transition-all neon-glow flex items-center justify-center group uppercase tracking-widest text-sm shadow-xl shadow-purple-600/20">
            Listen to Beats
          </a>
          <button 
            onClick={onOpenRegister}
            className="w-full sm:w-auto px-10 py-5 bg-white/5 hover:bg-white/10 text-white border border-white/10 font-black rounded-xl transition-all uppercase tracking-widest text-sm"
          >
            Register Account
          </button>
        </div>
      </div>
    </section>
  );
};

export default Hero;
