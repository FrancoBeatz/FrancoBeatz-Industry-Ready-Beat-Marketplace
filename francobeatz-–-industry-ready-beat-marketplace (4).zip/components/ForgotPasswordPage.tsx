
import React, { useState } from 'react';

const ForgotPasswordPage: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Reset failed");
      setSuccess(true);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="pt-32 pb-20 container mx-auto px-6 max-w-xl min-h-screen">
      <button onClick={onBack} className="flex items-center space-x-2 text-gray-500 hover:text-white transition-colors mb-12 text-xs font-bold uppercase tracking-widest">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
        <span>Back</span>
      </button>

      <div className="glass-card rounded-[40px] p-12 border border-purple-500/20">
        <h2 className="text-4xl font-black font-poppins uppercase tracking-tighter italic mb-4">Vault Recovery</h2>
        <p className="text-gray-500 mb-10 text-sm font-medium uppercase tracking-widest">Enter your email to receive a password reset link.</p>

        {error && <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 text-red-500 text-[10px] font-black rounded-xl text-center uppercase tracking-widest">{error}</div>}
        {success && (
          <div className="bg-purple-600/10 border border-purple-600/20 p-8 rounded-2xl text-center">
            <h4 className="text-purple-400 font-bold uppercase tracking-widest text-xs mb-2">Check Your Inbox</h4>
            <p className="text-gray-400 text-sm">Recovery instructions have been sent to {email}.</p>
          </div>
        )}

        {!success && (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-bold uppercase tracking-widest text-gray-500 ml-2">Email Address</label>
              <input required type="email" value={email} onChange={e => setEmail(e.target.value)} className="w-full bg-black/50 border border-white/10 rounded-xl px-6 py-4 text-white focus:border-purple-600 outline-none transition-colors" placeholder="email@example.com" />
            </div>
            <button type="submit" disabled={loading} className="w-full py-5 bg-purple-600 text-white font-black uppercase tracking-widest text-sm rounded-xl transition-all neon-glow flex items-center justify-center">
              {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : "Send Recovery Link"}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

export default ForgotPasswordPage;
