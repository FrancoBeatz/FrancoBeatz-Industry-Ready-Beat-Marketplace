
import { GoogleGenAI } from "@google/genai";
import React, { useState, useEffect } from 'react';
import { supabase } from '../supabase';
import { Beat } from '../types';

const AdminDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'INVENTORY' | 'SALES' | 'UPLOAD'>('INVENTORY');
  const [loading, setLoading] = useState(true);
  const [aiLoading, setAiLoading] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);
  const [inventory, setInventory] = useState<Beat[]>([]);
  const [editingBeat, setEditingBeat] = useState<Beat | null>(null);
  const [generatedDesc, setGeneratedDesc] = useState('');

  // Form State
  const [beatForm, setBeatForm] = useState({
    title: '',
    genre: 'Trap',
    bpm: 140,
    price: 9.99,
    audio_url: '',
    cover_url: '',
    tags: [] as string[]
  });

  useEffect(() => {
    fetchInventory();
  }, []);

  const fetchInventory = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('beats')
        .select('*')
        .order('created_at', { ascending: false });
        
      if (error) throw error;
      if (data) setInventory(data);
    } catch (err) {
      console.error("Failed to fetch inventory:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleEditClick = (beat: Beat) => {
    setEditingBeat(beat);
    setBeatForm({
      title: beat.title,
      genre: beat.genre,
      bpm: beat.bpm,
      price: beat.price,
      audio_url: beat.audio_url,
      cover_url: beat.cover_url,
      tags: beat.tags || []
    });
    setGeneratedDesc(beat.description || '');
    setActiveTab('UPLOAD');
  };

  const resetForm = () => {
    setEditingBeat(null);
    setBeatForm({ title: '', genre: 'Trap', bpm: 140, price: 9.99, audio_url: '', cover_url: '', tags: [] });
    setGeneratedDesc('');
  };

  const generateDescription = async (title: string, genre: string) => {
    if (!title) return alert("Enter a title first");
    
    setAiLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Write a high-energy, SEO description for a ${genre} beat titled "${title}". Focus on quality and vibes. Under 40 words.`,
      });
      setGeneratedDesc(response.text || '');
    } catch (e) {
      console.error("AI error:", e);
      setGeneratedDesc("An amazing beat crafted for professional artists.");
    } finally {
      setAiLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setActionLoading(true);

    try {
      if (editingBeat) {
        // Update existing
        const { error } = await supabase
          .from('beats')
          .update({ ...beatForm, description: generatedDesc })
          .eq('id', editingBeat.id);
        if (error) throw error;
        alert("Beat updated successfully!");
      } else {
        // Create new
        const { error } = await supabase.from('beats').insert([{
          ...beatForm,
          description: generatedDesc,
          is_exclusive: false,
          stock_quantity: 100
        }]);
        if (error) throw error;
        alert("Beat published successfully!");
      }

      resetForm();
      setActiveTab('INVENTORY');
      fetchInventory();
    } catch (err: any) {
      alert(err.message || "Operation failed. Check if you have Admin permissions.");
    } finally {
      setActionLoading(false);
    }
  };

  return (
    <div className="pt-32 pb-20 container mx-auto px-6 min-h-screen">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-12 gap-6">
        <div>
          <h1 className="text-5xl font-black font-poppins uppercase tracking-tighter italic mb-2">Producer Hub</h1>
          <p className="text-gray-500 font-medium uppercase tracking-widest text-xs">Admin Dashboard</p>
        </div>
        <div className="flex bg-white/5 p-1 rounded-2xl border border-white/5">
          <button onClick={() => { setActiveTab('INVENTORY'); resetForm(); }} className={`px-6 py-3 rounded-xl text-xs font-bold uppercase tracking-widest transition-all ${activeTab === 'INVENTORY' ? 'bg-purple-600 text-white shadow-lg' : 'text-gray-500 hover:text-white'}`}>Inventory</button>
          <button onClick={() => setActiveTab('SALES')} className={`px-6 py-3 rounded-xl text-xs font-bold uppercase tracking-widest transition-all ${activeTab === 'SALES' ? 'bg-purple-600 text-white shadow-lg' : 'text-gray-500 hover:text-white'}`}>Sales</button>
          <button onClick={() => setActiveTab('UPLOAD')} className={`px-6 py-3 rounded-xl text-xs font-bold uppercase tracking-widest transition-all ${activeTab === 'UPLOAD' ? 'bg-purple-600 text-white shadow-lg' : 'text-gray-500 hover:text-white'}`}>{editingBeat ? 'Edit Beat' : 'Upload'}</button>
        </div>
      </div>

      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="glass-card h-24 rounded-[24px] border border-white/5 flex items-center p-6 space-x-4 animate-pulse">
              <div className="w-12 h-12 bg-white/5 rounded-lg" />
              <div className="flex-grow space-y-2">
                <div className="h-4 w-1/4 bg-white/10 rounded" />
                <div className="h-3 w-1/6 bg-white/5 rounded" />
              </div>
            </div>
          ))}
        </div>
      ) : activeTab === 'INVENTORY' ? (
        <div className="glass-card rounded-[32px] overflow-hidden border border-white/5">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-white/5 bg-white/2">
                  <th className="p-6 text-xs font-bold uppercase tracking-[0.2em] text-gray-500">Beat</th>
                  <th className="p-6 text-xs font-bold uppercase tracking-[0.2em] text-gray-500">Price</th>
                  <th className="p-6 text-xs font-bold uppercase tracking-[0.2em] text-gray-500">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {inventory.length === 0 ? (
                  <tr>
                    <td colSpan={3} className="p-20 text-center text-gray-500 uppercase tracking-widest text-xs font-bold">No beats found.</td>
                  </tr>
                ) : (
                  inventory.map((beat) => (
                    <tr key={beat.id} className="hover:bg-white/2 transition-colors group">
                      <td className="p-6">
                        <div className="flex items-center space-x-4">
                          <img src={beat.cover_url} className="w-12 h-12 rounded-lg object-cover" alt="" />
                          <div>
                            <div className="font-bold text-white uppercase tracking-tight">{beat.title}</div>
                            <div className="text-[10px] text-gray-500 uppercase tracking-widest">{beat.genre} • {beat.bpm} BPM</div>
                          </div>
                        </div>
                      </td>
                      <td className="p-6 font-black text-purple-400 font-poppins text-lg">${beat.price.toFixed(2)}</td>
                      <td className="p-6">
                        <button 
                          onClick={() => handleEditClick(beat)}
                          className="px-6 py-2.5 bg-white/5 hover:bg-white/20 text-white rounded-xl text-[10px] font-black uppercase tracking-widest transition-all border border-white/5"
                        >
                          Edit
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : activeTab === 'UPLOAD' ? (
        <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="glass-card rounded-[32px] p-8 space-y-6 border border-white/5">
            <div className="flex justify-between items-center">
              <h3 className="text-xl font-bold uppercase tracking-tight italic font-poppins">{editingBeat ? 'Edit Beat Details' : 'New Release Info'}</h3>
              {editingBeat && (
                <button type="button" onClick={resetForm} className="text-[10px] font-bold text-purple-400 hover:text-purple-300 uppercase tracking-widest">Cancel Edit</button>
              )}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-gray-500 ml-2">Title</label>
                <input required value={beatForm.title} onChange={e => setBeatForm({...beatForm, title: e.target.value})} className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-sm focus:border-purple-600 outline-none transition-colors" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-gray-500 ml-2">Genre</label>
                <select value={beatForm.genre} onChange={e => setBeatForm({...beatForm, genre: e.target.value as any})} className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-sm focus:border-purple-600 outline-none transition-colors">
                  <option>Trap</option><option>Hip-Hop</option><option>Drill</option><option>R&B</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-gray-500 ml-2">Price ($)</label>
                <input required type="number" step="0.01" value={beatForm.price} onChange={e => setBeatForm({...beatForm, price: parseFloat(e.target.value)})} className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-sm focus:border-purple-600 outline-none transition-colors" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-gray-500 ml-2">BPM</label>
                <input required type="number" value={beatForm.bpm} onChange={e => setBeatForm({...beatForm, bpm: parseInt(e.target.value)})} className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-sm focus:border-purple-600 outline-none transition-colors" />
              </div>
              <div className="space-y-2 sm:col-span-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-gray-500 ml-2">Cover Image URL</label>
                <input required type="url" value={beatForm.cover_url} onChange={e => setBeatForm({...beatForm, cover_url: e.target.value})} className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-sm focus:border-purple-600 outline-none transition-colors" placeholder="https://..." />
              </div>
              <div className="space-y-2 sm:col-span-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-gray-500 ml-2">Audio File URL</label>
                <input required type="url" value={beatForm.audio_url} onChange={e => setBeatForm({...beatForm, audio_url: e.target.value})} className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-sm focus:border-purple-600 outline-none transition-colors" placeholder="https://..." />
              </div>
            </div>
            
            <button type="button" onClick={() => generateDescription(beatForm.title, beatForm.genre)} className="w-full py-3 bg-purple-600/10 border border-purple-500/20 text-purple-400 font-bold uppercase text-[10px] tracking-widest rounded-xl hover:bg-purple-600/20 transition-all">
              {aiLoading ? 'Thinking...' : 'Rewrite Description with Gemini'}
            </button>
            <textarea value={generatedDesc} onChange={e => setGeneratedDesc(e.target.value)} rows={4} className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-sm focus:border-purple-600 outline-none transition-colors resize-none" placeholder="Beat description..." />
            
            <button type="submit" disabled={actionLoading} className="w-full py-4 bg-purple-600 text-white font-black uppercase tracking-widest text-sm rounded-xl transition-all neon-glow flex items-center justify-center">
              {actionLoading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : editingBeat ? 'Save Changes' : 'Publish Beat'}
            </button>
          </div>
          <div className="glass-card rounded-[32px] p-8 flex flex-col items-center justify-center border border-white/5 bg-gradient-to-br from-purple-900/10 to-transparent">
             <div className="relative group">
               <img src={beatForm.cover_url || 'https://via.placeholder.com/400'} className="w-64 h-64 rounded-2xl object-cover mb-6 shadow-2xl border border-white/10 transition-transform group-hover:scale-105" alt="Preview" />
               <div className="absolute inset-0 bg-black/20 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity" />
             </div>
             <h4 className="font-bold text-white uppercase tracking-tighter text-2xl font-poppins italic">{beatForm.title || 'Untitled'}</h4>
             <p className="text-gray-500 text-[10px] font-black uppercase tracking-[0.2em] mt-2 bg-white/5 px-4 py-1 rounded-full">{beatForm.genre} • {beatForm.bpm} BPM</p>
             <div className="mt-6 text-2xl font-black text-purple-400 font-poppins">${beatForm.price.toFixed(2)}</div>
          </div>
        </form>
      ) : activeTab === 'SALES' ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { label: 'Total Revenue', value: '$2,450.00' },
            { label: 'Recent Orders', value: '12' },
            { label: 'Profile Views', value: '1.2k' }
          ].map((stat, i) => (
            <div key={i} className="glass-card rounded-[32px] p-10 border border-white/5 text-center">
              <div className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-2">{stat.label}</div>
              <div className="text-4xl font-black text-white font-poppins italic">{stat.value}</div>
            </div>
          ))}
        </div>
      ) : null}
    </div>
  );
};

export default AdminDashboard;
