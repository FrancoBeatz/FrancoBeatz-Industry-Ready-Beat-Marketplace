import React, { useState, useEffect } from 'react';
import { supabase } from '../supabase';
import { Order } from '../types';

const OrderHistory: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    setLoading(true);
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return;

    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .eq('user_id', session.user.id)
      .order('created_at', { ascending: false });

    if (data) setOrders(data);
    setLoading(false);
  };

  return (
    <div className="pt-32 pb-20 container mx-auto px-6 min-h-screen">
      <div className="mb-12">
        <h1 className="text-5xl font-black font-poppins uppercase tracking-tighter italic mb-2">My Vault</h1>
        <p className="text-gray-500 font-medium uppercase tracking-widest text-xs">Purchase History & Downloads</p>
      </div>

      {loading ? (
        <div className="space-y-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="glass-card h-24 rounded-2xl animate-pulse"></div>
          ))}
        </div>
      ) : orders.length === 0 ? (
        <div className="glass-card rounded-[32px] p-20 text-center">
          <p className="text-gray-500 font-bold uppercase tracking-widest text-sm mb-6">No orders found in your vault.</p>
          <a href="#beats" className="inline-block px-10 py-4 bg-purple-600 text-white font-black uppercase tracking-widest text-[10px] rounded-xl neon-glow">
            Browse Beats
          </a>
        </div>
      ) : (
        <div className="space-y-6">
          {orders.map((order) => (
            <div key={order.id} className="glass-card rounded-[32px] p-8 border border-white/5 group hover:border-purple-500/30 transition-all">
              <div className="flex flex-col md:flex-row justify-between gap-6">
                <div className="flex-grow">
                  <div className="flex items-center space-x-3 mb-2">
                    <span className="text-[10px] font-black uppercase tracking-widest text-purple-400">Order #{order.id.slice(0, 8).toUpperCase()}</span>
                    <span className={`px-3 py-1 text-[8px] font-black rounded-full uppercase tracking-widest ${order.status === 'COMPLETED' ? 'bg-green-500/10 text-green-500' : 'bg-orange-500/10 text-orange-500'}`}>
                      {order.status}
                    </span>
                  </div>
                  <h3 className="text-xl font-bold text-white mb-4">
                    {order.items?.length} {order.items?.length === 1 ? 'Beat' : 'Beats'} Purchased
                  </h3>
                  <div className="flex -space-x-3">
                    {order.items?.map((item: any, idx: number) => (
                      <img 
                        key={idx} 
                        src={item.cover_url} 
                        className="w-12 h-12 rounded-lg border-2 border-[#0a0a0a] object-cover" 
                        alt={item.title} 
                      />
                    ))}
                  </div>
                </div>

                <div className="flex flex-col md:items-end justify-between">
                  <div className="text-right">
                    <div className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">
                      {new Date(order.created_at).toLocaleDateString()}
                    </div>
                    <div className="text-2xl font-black text-white">${order.total_amount.toFixed(2)}</div>
                  </div>
                  <button className="mt-4 px-8 py-3 bg-white/5 hover:bg-white text-gray-500 hover:text-black font-black uppercase tracking-widest text-[10px] rounded-xl transition-all">
                    Download Files
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default OrderHistory;