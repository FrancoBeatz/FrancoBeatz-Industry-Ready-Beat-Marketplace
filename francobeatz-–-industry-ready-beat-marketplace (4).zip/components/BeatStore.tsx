
import React, { useState, useRef, useEffect } from 'react';
import { supabase } from '../supabase';
import { Beat } from '../types';

const BeatSkeleton = () => (
  <div className="glass-card rounded-[32px] overflow-hidden border border-white/5 animate-pulse">
    <div className="aspect-square bg-white/5" />
    <div className="p-8 space-y-4">
      <div className="flex justify-between">
        <div className="h-6 w-1/2 bg-white/10 rounded" />
        <div className="h-6 w-1/4 bg-white/10 rounded" />
      </div>
      <div className="h-4 w-full bg-white/5 rounded" />
      <div className="h-12 w-full bg-white/5 rounded-2xl" />
    </div>
  </div>
);

const SQL_SETUP_COMMAND = `
-- RUN THIS IN SUPABASE SQL EDITOR
CREATE TABLE IF NOT EXISTS public.beats (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  genre TEXT NOT NULL,
  bpm INTEGER,
  price DECIMAL(10,2) NOT NULL,
  audio_url TEXT NOT NULL,
  cover_url TEXT NOT NULL,
  tags TEXT[],
  description TEXT,
  is_exclusive BOOLEAN DEFAULT FALSE,
  stock_quantity INTEGER DEFAULT 100,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);
`.trim();

const BeatCard: React.FC<{ 
  beat: Beat; 
  activeBeatId: string | null; 
  onTogglePlay: (id: string) => void;
  onAddToCart: (beat: Beat) => void;
  progress: number;
  isPaused: boolean;
}> = ({ beat, activeBeatId, onTogglePlay, onAddToCart, progress, isPaused }) => {
  const isActive = activeBeatId === beat.id;

  return (
    <div className="glass-card rounded-[32px] overflow-hidden group hover:border-purple-500/30 transition-all duration-500 border border-white/5">
      <div className="relative aspect-square overflow-hidden bg-black">
        <img 
          src={beat.cover_url || 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?q=80&w=800&auto=format&fit=crop'} 
          alt={beat.title} 
          className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" 
          loading="lazy"
        />
        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-[4px]">
          <button 
            onClick={() => onTogglePlay(beat.id)}
            className="w-16 h-16 bg-purple-600 rounded-full flex items-center justify-center text-white transform scale-90 group-hover:scale-100 transition-transform neon-glow"
          >
            {isActive && !isPaused ? (
               <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 ml-1" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" />
              </svg>
            )}
          </button>
        </div>
        {isActive && <div className="absolute bottom-0 left-0 h-1 bg-purple-500 z-20" style={{ width: `${progress}%` }} />}
        <div className="absolute top-6 left-6 flex space-x-2 z-10">
          <div className="bg-black/80 backdrop-blur-md text-[10px] font-black uppercase tracking-widest px-3 py-1.5 rounded-xl border border-white/10">{beat.bpm} BPM</div>
          <div className="bg-purple-600 text-[10px] font-black uppercase tracking-widest px-3 py-1.5 rounded-xl neon-glow">{beat.genre}</div>
        </div>
      </div>
      <div className="p-8">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-2xl font-black font-poppins text-white tracking-tight uppercase italic">{beat.title}</h3>
          <span className="text-xl font-black tracking-tight text-white">${beat.price}</span>
        </div>
        <div className="flex flex-wrap gap-2 mb-8 h-12 overflow-hidden">
          {beat.tags?.map(tag => (
            <span key={tag} className="text-[10px] uppercase font-bold text-gray-500 border border-white/10 px-3 py-1 rounded-full">#{tag}</span>
          ))}
        </div>
        <button onClick={() => onAddToCart(beat)} className="w-full bg-white/5 hover:bg-white text-gray-400 hover:text-black font-black uppercase tracking-[0.2em] text-[10px] py-4 rounded-2xl transition-all">Add to Cart</button>
      </div>
    </div>
  );
};

const BeatStore: React.FC<{ onAddToCart: (beat: Beat) => void }> = ({ onAddToCart }) => {
  const [beats, setBeats] = useState<Beat[]>([]);
  const [loading, setLoading] = useState(true);
  const [dbError, setDbError] = useState<string | null>(null);
  const [activeBeatId, setActiveBeatId] = useState<string | null>(null);
  const [isPaused, setIsPaused] = useState(false);
  const [progress, setProgress] = useState(0);
  const [filter, setFilter] = useState('All');
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    fetchBeats();
    return () => { if (audioRef.current) audioRef.current.pause(); };
  }, []);

  const fetchBeats = async () => {
    setLoading(true);
    setDbError(null);
    try {
      const { data, error } = await supabase.from('beats').select('*').order('created_at', { ascending: false });
      
      if (error) {
        if (error.code === 'PGRST205' || error.message.includes('public.beats')) {
           setDbError("DATABASE_SETUP_REQUIRED");
        }
        throw error;
      }
      
      if (data) setBeats(data);
    } catch (err: any) { 
      console.error("Fetch beats error:", err); 
    } finally {
      setLoading(false);
    }
  };

  const handleTogglePlay = async (id: string) => {
    const selectedBeat = beats.find(b => b.id === id);
    if (!selectedBeat) return;

    if (activeBeatId === id) {
      if (audioRef.current?.paused) {
        await audioRef.current.play();
        setIsPaused(false);
      } else {
        audioRef.current?.pause();
        setIsPaused(true);
      }
    } else {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.src = "";
      }
      
      setActiveBeatId(id);
      setIsPaused(false);
      setProgress(0);
      
      const audio = new Audio(selectedBeat.audio_url);
      audioRef.current = audio;
      
      audio.ontimeupdate = () => {
        if (audio.duration) {
          setProgress((audio.currentTime / audio.duration) * 100);
        }
      };
      
      audio.onended = () => {
        setActiveBeatId(null);
        setProgress(0);
      };

      try {
        await audio.play();
      } catch (e) {
        console.error("Audio play error:", e);
        setActiveBeatId(null);
      }
    }
  };

  const filteredBeats = filter === 'All' ? beats : beats.filter(b => b.genre === filter);

  return (
    <section id="beats" className="py-40 bg-[#050505]">
      <div className="container mx-auto px-6">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between mb-24 gap-10">
          <div className="max-w-xl">
            <h2 className="text-6xl font-black mb-6 font-poppins text-white uppercase tracking-tighter italic leading-none">The Vault</h2>
            <p className="text-gray-500 font-medium">Industry engineered foundation for your next hit.</p>
          </div>
          <div className="flex bg-white/5 p-1 rounded-2xl border border-white/5 overflow-x-auto custom-scrollbar">
            {['All', 'Trap', 'Drill', 'Hip-Hop', 'R&B'].map(f => (
              <button key={f} onClick={() => setFilter(f)} className={`px-8 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest whitespace-nowrap transition-all ${filter === f ? 'bg-purple-600 text-white shadow-xl' : 'text-gray-500 hover:text-white'}`}>{f}</button>
            ))}
          </div>
        </div>

        {dbError === "DATABASE_SETUP_REQUIRED" ? (
          <div className="glass-card rounded-[40px] p-12 border border-orange-500/30">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-black text-orange-400 mb-4 uppercase italic tracking-tighter">Database Table Missing</h3>
              <p className="text-gray-400 mb-8 max-w-lg mx-auto leading-relaxed">
                The <code className="text-white px-1.5 bg-white/10 rounded">public.beats</code> table was not found in your Supabase project. 
                Please copy and run the SQL below in your <strong>Supabase SQL Editor</strong>:
              </p>
            </div>
            
            <div className="bg-black/80 rounded-2xl p-6 mb-8 border border-white/10 font-mono text-[11px] text-green-400 relative group">
              <pre className="whitespace-pre-wrap">{SQL_SETUP_COMMAND}</pre>
              <button 
                onClick={() => {
                  navigator.clipboard.writeText(SQL_SETUP_COMMAND);
                  alert("Copied to clipboard! Now paste it into Supabase SQL Editor.");
                }}
                className="absolute top-4 right-4 bg-white/10 hover:bg-white/20 text-white px-3 py-1 rounded text-[9px] uppercase font-bold"
              >
                Copy SQL
              </button>
            </div>

            <div className="flex justify-center">
              <button 
                onClick={fetchBeats} 
                className="px-8 py-3 bg-purple-600 text-white font-black uppercase tracking-widest text-[10px] rounded-xl hover:bg-purple-700 transition-all neon-glow"
              >
                Retry Connection
              </button>
            </div>
          </div>
        ) : loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            {[1, 2, 3, 4, 5, 6].map(i => <BeatSkeleton key={i} />)}
          </div>
        ) : beats.length === 0 ? (
          <div className="text-center py-20 text-gray-500 uppercase font-black tracking-widest text-sm italic">
            No beats have been uploaded to the vault yet.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            {filteredBeats.map(beat => (
              <BeatCard key={beat.id} beat={beat} activeBeatId={activeBeatId} isPaused={isPaused} onTogglePlay={handleTogglePlay} onAddToCart={onAddToCart} progress={activeBeatId === beat.id ? progress : 0} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
};

export default BeatStore;
