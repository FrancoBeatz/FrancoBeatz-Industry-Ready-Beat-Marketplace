
import { getSupabaseAdmin } from '../supabase';

export default async function handler(req: any, res: any) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { email, password, name } = req.body;
  const supabaseAdmin = getSupabaseAdmin();

  try {
    const { data: authUser, error: authError } = await supabaseAdmin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { full_name: name }
    });

    if (authError) throw authError;

    const { error: profileError } = await supabaseAdmin
      .from('profiles')
      .insert([{ id: authUser.user.id, email, role: 'CUSTOMER', full_name: name }]);

    if (profileError) throw profileError;

    return res.status(201).json({ success: true, message: "User registered successfully" });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || "Registration failed" });
  }
}
